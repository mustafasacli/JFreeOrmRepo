package jv.freeorm.logic;

/**
 *
 * @author Mustafa SACLI
 */
public interface IBaseDL extends IBaseOperations, AutoCloseable {

}
